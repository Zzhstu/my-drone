#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ROS node for P450/G1 no-flight YOLO detection + click/auto single-object tracking.
Outputs are compatible with SpireCV ROS:
  /uav1/spirecv/target    spirecv_msgs/TargetsInFrame
  /uav1/spirecv/image_det sensor_msgs/Image
Supported backends:
  backend:=ultralytics  YOLO11/YOLO26/Ultralytics-exported TensorRT .engine
  backend:=yolov5_hub   original ultralytics/yolov5 custom .pt through torch.hub local repo
"""
import os
import math
import time
import cv2
import rospy
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from spirecv_msgs.msg import Target, TargetsInFrame, Control

try:
    from ultralytics import YOLO
except Exception as e:
    YOLO = None
    ULTRA_ERR = e
else:
    ULTRA_ERR = None

try:
    import torch
except Exception as e:
    torch = None
    TORCH_ERR = e
else:
    TORCH_ERR = None


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def parse_classes(s):
    if s in [None, '', 'all', 'ALL']:
        return None
    if isinstance(s, list):
        return [int(x) for x in s]
    return [int(x.strip()) for x in str(s).split(',') if x.strip()]


def make_tracker(name):
    name = str(name).upper()
    creators = []
    if hasattr(cv2, 'legacy'):
        creators += [getattr(cv2.legacy, 'Tracker%s_create' % name, None)]
        for n in ['CSRT', 'KCF', 'MOSSE', 'MIL']:
            creators.append(getattr(cv2.legacy, 'Tracker%s_create' % n, None))
    creators += [getattr(cv2, 'Tracker%s_create' % name, None)]
    for n in ['CSRT', 'KCF', 'MOSSE', 'MIL']:
        creators.append(getattr(cv2, 'Tracker%s_create' % n, None))
    for c in creators:
        if c:
            try:
                return c()
            except Exception:
                pass
    return None


class YoloBackend:
    def __init__(self, backend, model_path, imgsz, conf, iou, classes, max_det, device, yolov5_repo):
        self.backend = backend
        self.model_path = os.path.expanduser(model_path)
        self.imgsz = int(imgsz)
        self.conf = float(conf)
        self.iou = float(iou)
        self.classes = classes
        self.max_det = int(max_det)
        self.device = str(device)
        self.yolov5_repo = os.path.expanduser(yolov5_repo)
        self.names = {}
        self.model = None
        self._load()

    def _load(self):
        if self.backend == 'auto':
            lower = os.path.basename(self.model_path).lower()
            self.backend = 'yolov5_hub' if 'yolov5' in lower and os.path.isdir(self.yolov5_repo) else 'ultralytics'

        if self.backend == 'ultralytics':
            if YOLO is None:
                raise RuntimeError('Cannot import ultralytics. Install with: pip3 install ultralytics. Error: %r' % ULTRA_ERR)
            self.model = YOLO(self.model_path)
            self.names = getattr(self.model, 'names', {}) or {}
            rospy.loginfo('Loaded Ultralytics model: %s', self.model_path)
        elif self.backend == 'yolov5_hub':
            if torch is None:
                raise RuntimeError('Cannot import torch. Install PyTorch first. Error: %r' % TORCH_ERR)
            if not os.path.isdir(self.yolov5_repo):
                raise RuntimeError('backend=yolov5_hub requires yolov5_repo, e.g. /home/amov/yolov5')
            self.model = torch.hub.load(self.yolov5_repo, 'custom', path=self.model_path, source='local')
            self.model.conf = self.conf
            self.model.iou = self.iou
            self.model.max_det = self.max_det
            if self.classes is not None:
                self.model.classes = self.classes
            if self.device not in ['cpu', 'CPU', '-1']:
                self.model.to('cuda:%s' % self.device if self.device.isdigit() else self.device)
            self.names = getattr(self.model, 'names', {}) or {}
            rospy.loginfo('Loaded original YOLOv5 model: %s repo=%s', self.model_path, self.yolov5_repo)
        else:
            raise RuntimeError('Unknown backend=%s, use auto|ultralytics|yolov5_hub' % self.backend)

    def predict(self, img):
        dets = []
        t0 = time.time()
        if self.backend == 'ultralytics':
            r = self.model.predict(img, imgsz=self.imgsz, conf=self.conf, iou=self.iou,
                                   classes=self.classes, max_det=self.max_det, device=self.device,
                                   verbose=False)[0]
            if r.boxes is not None:
                boxes = r.boxes.xyxy.cpu().numpy()
                scores = r.boxes.conf.cpu().numpy()
                clss = r.boxes.cls.cpu().numpy().astype(int)
                for box, score, cls_id in zip(boxes, scores, clss):
                    d = self._format_det(box, score, cls_id)
                    if d is not None:
                        dets.append(d)
        else:
            res = self.model(img, size=self.imgsz)
            arr = res.xyxy[0].detach().cpu().numpy() if len(res.xyxy) else []
            for row in arr:
                x1, y1, x2, y2, score, cls_id = row[:6]
                d = self._format_det((x1, y1, x2, y2), score, int(cls_id))
                if d is not None:
                    dets.append(d)
        return dets, (time.time() - t0) * 1000.0

    def _format_det(self, box, score, cls_id):
        x1, y1, x2, y2 = [int(round(float(v))) for v in box]
        if x2 <= x1 or y2 <= y1:
            return None
        if isinstance(self.names, dict):
            name = self.names.get(int(cls_id), str(int(cls_id)))
        elif isinstance(self.names, (list, tuple)) and int(cls_id) < len(self.names):
            name = self.names[int(cls_id)]
        else:
            name = str(int(cls_id))
        return {'bbox': (x1, y1, x2 - x1, y2 - y1), 'score': float(score), 'cls_id': int(cls_id), 'name': str(name)}


class Node:
    def __init__(self):
        self.uav_id = int(rospy.get_param('~uav_id', 1))
        self.model_path = rospy.get_param('~model_path', '/home/amov/SpireCV/models/yolo11n.pt')
        self.model_name = rospy.get_param('~model_name', os.path.basename(self.model_path))
        self.backend = rospy.get_param('~backend', 'auto')
        self.yolov5_repo = rospy.get_param('~yolov5_repo', '/home/amov/yolov5')
        self.device = rospy.get_param('~device', '0')
        self.imgsz = int(rospy.get_param('~imgsz', 640))
        self.conf = float(rospy.get_param('~conf', 0.35))
        self.iou = float(rospy.get_param('~iou', 0.45))
        self.classes = parse_classes(rospy.get_param('~classes', 'all'))
        self.max_det = int(rospy.get_param('~max_det', 50))
        self.input_topic = rospy.get_param('~input_image_topic', '/uav%d/gimbal/image_original' % self.uav_id)
        self.output_topic = rospy.get_param('~output_image_topic', '/uav%d/spirecv/image_det' % self.uav_id)
        self.target_topic = rospy.get_param('~target_topic', '/uav%d/spirecv/target' % self.uav_id)
        self.control_topic = rospy.get_param('~control_topic', '/uav%d/spirecv/control' % self.uav_id)
        self.fov_x = float(rospy.get_param('~fov_x', 60.0))
        self.fov_y = float(rospy.get_param('~fov_y', 39.0))
        self.target_w_m = float(rospy.get_param('~target_real_width_m', 0.0))
        self.target_h_m = float(rospy.get_param('~target_real_height_m', 0.0))
        self.auto_select = bool(rospy.get_param('~auto_select', False))
        self.auto_policy = rospy.get_param('~auto_select_policy', 'highest_score')
        self.enable_tracking = bool(rospy.get_param('~enable_tracking', True))
        self.tracker_type = rospy.get_param('~tracker_type', 'CSRT')
        self.lost_threshold = int(rospy.get_param('~lost_threshold', 20))
        self.enable_ui = bool(rospy.get_param('~enable_ui', False))
        self.log_every_n = int(rospy.get_param('~log_every_n', 30))

        self.detector = YoloBackend(self.backend, self.model_path, self.imgsz, self.conf, self.iou, self.classes, self.max_det, self.device, self.yolov5_repo)
        self.bridge = CvBridge()
        self.frame_id = 0
        self.last_time = rospy.Time.now()
        self.fps = 0.0
        self.infer_ms = 0.0
        self.click = None
        self.tracker = None
        self.tracking = False
        self.bbox = None
        self.no_track = 999
        self.cat = 'target'
        self.cat_id = -1
        self.score = 1.0
        self.last_w = 1
        self.last_h = 1

        self.pub_img = rospy.Publisher(self.output_topic, Image, queue_size=1)
        self.pub_tgt = rospy.Publisher(self.target_topic, TargetsInFrame, queue_size=1)
        self.sub_img = rospy.Subscriber(self.input_topic, Image, self.cb_img, queue_size=1, buff_size=2 ** 24)
        self.sub_ctl = rospy.Subscriber(self.control_topic, Control, self.cb_ctl, queue_size=10)
        if self.enable_ui:
            cv2.namedWindow('P450 YOLO Detect Track', cv2.WINDOW_NORMAL)
            cv2.setMouseCallback('P450 YOLO Detect Track', self.cb_mouse)
        rospy.loginfo('YOLO node ready: backend=%s model=%s input=%s target=%s', self.detector.backend, self.model_path, self.input_topic, self.target_topic)

    def cb_ctl(self, msg):
        if msg.mouse == Control.MOUSE_LEFT:
            self.click = (float(msg.x), float(msg.y))
        elif msg.mouse == Control.MOUSE_RIGHT:
            self.reset()

    def cb_mouse(self, event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN:
            self.click = (x / max(1, self.last_w), y / max(1, self.last_h))
        elif event == cv2.EVENT_RBUTTONDOWN:
            self.reset()

    def reset(self):
        self.tracker = None
        self.tracking = False
        self.bbox = None
        self.no_track = 999

    def update_fps(self, stamp):
        now = stamp if stamp != rospy.Time() else rospy.Time.now()
        dt = (now - self.last_time).to_sec()
        self.last_time = now
        inst = 1.0 / dt if dt > 1e-4 else 0.0
        self.fps = inst if self.fps <= 0 else 0.9 * self.fps + 0.1 * inst

    def select_click(self, dets, click, w, h):
        px, py = clamp(click[0], 0.0, 1.0) * w, clamp(click[1], 0.0, 1.0) * h
        inside = []
        for d in dets:
            x, y, bw, bh = d['bbox']
            if x <= px <= x + bw and y <= py <= y + bh:
                inside.append(d)
        if inside:
            return max(inside, key=lambda d: d['score'])
        return min(dets, key=lambda d: (d['bbox'][0] + d['bbox'][2] / 2 - px) ** 2 + (d['bbox'][1] + d['bbox'][3] / 2 - py) ** 2)

    def select_auto(self, dets, w, h):
        if not dets:
            return None
        if self.auto_policy == 'center':
            return min(dets, key=lambda d: (d['bbox'][0] + d['bbox'][2] / 2 - w / 2) ** 2 + (d['bbox'][1] + d['bbox'][3] / 2 - h / 2) ** 2)
        if self.auto_policy == 'largest':
            return max(dets, key=lambda d: d['bbox'][2] * d['bbox'][3])
        return max(dets, key=lambda d: d['score'])

    def init_track(self, img, d):
        self.bbox = tuple(int(v) for v in d['bbox'])
        self.cat = d['name']; self.cat_id = d['cls_id']; self.score = d['score']; self.no_track = 0
        self.tracker = make_tracker(self.tracker_type) if self.enable_tracking else None
        if self.tracker is not None:
            self.tracker.init(img, self.bbox)
        self.tracking = True
        rospy.loginfo('track init category=%s score=%.3f bbox=%s tracker=%s', self.cat, self.score, self.bbox, self.tracker_type)

    def target_from_bbox(self, bbox, w, h, score, cat, cat_id, mode):
        x, y, bw, bh = bbox
        x = int(clamp(x, 0, w - 1)); y = int(clamp(y, 0, h - 1))
        bw = int(clamp(bw, 1, w - x)); bh = int(clamp(bh, 1, h - y))
        cx = (x + bw / 2.0) / float(w); cy = (y + bh / 2.0) / float(h)
        nw = bw / float(w); nh = bh / float(h)
        t = Target()
        t.cx = cx; t.cy = cy; t.w = nw; t.h = nh
        t.score = float(score); t.category = str(cat); t.category_id = int(cat_id)
        t.tracked_id = 0; t.mode = bool(mode); t.sim_score = 1.0 if mode else 0.0
        t.los_ax = (cx - 0.5) * self.fov_x; t.los_ay = (cy - 0.5) * self.fov_y; t.yaw_a = t.los_ax
        z = []
        if self.target_w_m > 1e-3 and nw > 1e-5:
            z.append(self.target_w_m / (2.0 * math.tan(math.radians(self.fov_x) / 2.0) * nw))
        if self.target_h_m > 1e-3 and nh > 1e-5:
            z.append(self.target_h_m / (2.0 * math.tan(math.radians(self.fov_y) / 2.0) * nh))
        if z:
            t.pz = sum(z) / len(z)
            t.px = math.tan(math.radians(t.los_ax)) * t.pz
            t.py = math.tan(math.radians(t.los_ay)) * t.pz
        return t

    def draw(self, img, t, locked):
        h, w = img.shape[:2]
        x1 = int((t.cx - t.w / 2) * w); y1 = int((t.cy - t.h / 2) * h)
        x2 = int((t.cx + t.w / 2) * w); y2 = int((t.cy + t.h / 2) * h)
        color = (0, 255, 0) if locked else (255, 170, 0)
        cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
        label = ('TRACK ' if locked else 'DET ') + '%s %.2f' % (t.category, t.score)
        cv2.putText(img, label, (x1, max(20, y1 - 5)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)

    def cb_img(self, msg):
        try:
            img = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception as e:
            rospy.logerr('cv_bridge conversion failed: %s', e)
            return
        h, w = img.shape[:2]
        self.last_w = w; self.last_h = h; self.frame_id += 1; self.update_fps(msg.header.stamp)
        dets = []
        if not self.tracking:
            dets, self.infer_ms = self.detector.predict(img)
        if self.click is not None and dets:
            self.init_track(img, self.select_click(dets, self.click, w, h)); self.click = None
        elif self.auto_select and (not self.tracking) and dets:
            self.init_track(img, self.select_auto(dets, w, h))
        locked_t = None
        if self.tracking:
            if self.tracker is not None:
                ok, bbox = self.tracker.update(img)
                if ok:
                    self.bbox = tuple(int(v) for v in bbox); self.no_track = 0
                else:
                    self.no_track += 1
            if self.no_track <= self.lost_threshold and self.bbox is not None:
                locked_t = self.target_from_bbox(self.bbox, w, h, self.score, self.cat, self.cat_id, True)
            else:
                self.reset()
        out = TargetsInFrame(); out.header = msg.header; out.frame_id = self.frame_id
        out.height = h; out.width = w; out.fps = self.fps; out.fov_x = self.fov_x; out.fov_y = self.fov_y; out.no_track_frame_count = self.no_track
        vis = img.copy()
        if locked_t:
            out.targets.append(locked_t); self.draw(vis, locked_t, True)
        else:
            for d in dets:
                t = self.target_from_bbox(d['bbox'], w, h, d['score'], d['name'], d['cls_id'], False)
                out.targets.append(t); self.draw(vis, t, False)
        if self.log_every_n > 0 and self.frame_id % self.log_every_n == 0:
            rospy.loginfo('%s backend=%s fps=%.1f infer=%.1fms targets=%d tracking=%s', self.model_name, self.detector.backend, self.fps, self.infer_ms, len(out.targets), self.tracking)
        cv2.putText(vis, '%s FPS:%.1f infer:%.1fms tracking:%s' % (self.model_name, self.fps, self.infer_ms, self.tracking), (15, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
        self.pub_tgt.publish(out)
        self.pub_img.publish(self.bridge.cv2_to_imgmsg(vis, 'bgr8'))
        if self.enable_ui:
            cv2.imshow('P450 YOLO Detect Track', vis); cv2.waitKey(1)


if __name__ == '__main__':
    rospy.init_node('yolo_detect_track_node')
    Node()
    rospy.spin()
